
#ifndef TASK_FILEIO_H
#define TASK_FILEIO_H

int task_fileio(int argc, char *argv[]);

#endif

