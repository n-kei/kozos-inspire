
#ifndef _TASK_INPUT_H_
#define _TASK_INPUT_H_

int task_input(int argc, char *argv[]);

#endif

