#ifndef _RE_H_INCLUDED_
#define _RE_H_INCLUDED_

#include "defines.h"

int re_init(void);
uint16 re_read(void);

#endif

