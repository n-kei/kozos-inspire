
#ifndef DISPLAY_H
#define DISPLAY_H

int task_display(int argc, char *argv[]);

#endif

