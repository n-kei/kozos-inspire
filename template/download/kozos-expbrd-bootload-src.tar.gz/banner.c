
#include "banner.h"
#include "lib.h"

void banner(void)
{
    puts("\n");
    puts("========================================================\n");
    puts(" KOZOS EXPBRD Boot Loader Version 0.0.1                 \n");
    puts("========================================================\n");
}

