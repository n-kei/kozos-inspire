#ifndef _XMODEM_H_INCLUDED_
#define _XMODEM_H_INCLUDED_

long xmodem_recv(char *buf);

#endif
