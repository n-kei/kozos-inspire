#ifndef BOOT_H
#define BOOT_H

void boot_from_sdc(const char *filename);
void boot_from_ser(void);

#endif

