#ifndef _ELF_H_INCLUDED_
#define _ELF_H_INCLUDED_

char *elf_load(char *buf);

#endif
