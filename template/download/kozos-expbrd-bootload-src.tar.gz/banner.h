#ifndef BANNER_H
#define BANNER_H

void banner(void);

#endif

