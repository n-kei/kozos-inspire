#ifndef INIT_H
#define INIT_H

int init_system(void);
int init_components(void);

#endif

