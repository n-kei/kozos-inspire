#ifndef SPREG_H
#define SPREG_H

#include "defines.h"

void spreg_itu_init(void);
void spreg_itu_counter(uint16 *value);
void spreg_dram_init(void);

#endif

